﻿namespace iss_bar_ho_jaega
{
    partial class DAQHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Purge1 = new System.Windows.Forms.Button();
            this.label_x1 = new System.Windows.Forms.Label();
            this.label_y1 = new System.Windows.Forms.Label();
            this.label_z1 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Load_file1 = new System.Windows.Forms.Button();
            this.Purge2 = new System.Windows.Forms.Button();
            this.label_x2 = new System.Windows.Forms.Label();
            this.label_y2 = new System.Windows.Forms.Label();
            this.label_z2 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.Load_file2 = new System.Windows.Forms.Button();
            this.file2 = new System.Windows.Forms.Label();
            this.file1 = new System.Windows.Forms.Label();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.elementHost2 = new System.Windows.Forms.Integration.ElementHost();
            this.gauge11 = new iss_bar_ho_jaega.Gauge1();
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.gauge1 = new iss_bar_ho_jaega.Gauge();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            this.SuspendLayout();
            // 
            // Purge1
            // 
            this.Purge1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Purge1.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.Purge1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkOrchid;
            this.Purge1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Purge1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Purge1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Purge1.ForeColor = System.Drawing.Color.Lime;
            this.Purge1.Location = new System.Drawing.Point(933, 214);
            this.Purge1.Name = "Purge1";
            this.Purge1.Size = new System.Drawing.Size(75, 30);
            this.Purge1.TabIndex = 60;
            this.Purge1.Text = "Purge";
            this.Purge1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Purge1.UseVisualStyleBackColor = true;
            this.Purge1.Click += new System.EventHandler(this.Purge1_Click);
            // 
            // label_x1
            // 
            this.label_x1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_x1.AutoEllipsis = true;
            this.label_x1.BackColor = System.Drawing.Color.Transparent;
            this.label_x1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_x1.ForeColor = System.Drawing.Color.Lime;
            this.label_x1.Location = new System.Drawing.Point(802, 84);
            this.label_x1.Name = "label_x1";
            this.label_x1.Size = new System.Drawing.Size(96, 24);
            this.label_x1.TabIndex = 59;
            this.label_x1.Text = "Channel 1";
            // 
            // label_y1
            // 
            this.label_y1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_y1.AutoEllipsis = true;
            this.label_y1.BackColor = System.Drawing.Color.Transparent;
            this.label_y1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_y1.ForeColor = System.Drawing.Color.Lime;
            this.label_y1.Location = new System.Drawing.Point(802, 117);
            this.label_y1.Name = "label_y1";
            this.label_y1.Size = new System.Drawing.Size(96, 24);
            this.label_y1.TabIndex = 58;
            this.label_y1.Text = "Channel 2";
            // 
            // label_z1
            // 
            this.label_z1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_z1.AutoEllipsis = true;
            this.label_z1.BackColor = System.Drawing.Color.Transparent;
            this.label_z1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_z1.ForeColor = System.Drawing.Color.Lime;
            this.label_z1.Location = new System.Drawing.Point(802, 151);
            this.label_z1.Name = "label_z1";
            this.label_z1.Size = new System.Drawing.Size(96, 24);
            this.label_z1.TabIndex = 57;
            this.label_z1.Text = "Channel 3";
            // 
            // comboBox3
            // 
            this.comboBox3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(913, 156);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(100, 21);
            this.comboBox3.TabIndex = 54;
            // 
            // comboBox2
            // 
            this.comboBox2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(913, 122);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(100, 21);
            this.comboBox2.TabIndex = 53;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(913, 89);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 52;
            // 
            // Load_file1
            // 
            this.Load_file1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Load_file1.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.Load_file1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkOrchid;
            this.Load_file1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Load_file1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Load_file1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Load_file1.ForeColor = System.Drawing.Color.Lime;
            this.Load_file1.Location = new System.Drawing.Point(806, 214);
            this.Load_file1.Name = "Load_file1";
            this.Load_file1.Size = new System.Drawing.Size(75, 30);
            this.Load_file1.TabIndex = 51;
            this.Load_file1.Text = "Initiate";
            this.Load_file1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Load_file1.UseVisualStyleBackColor = true;
            this.Load_file1.Click += new System.EventHandler(this.Load_file1_Click);
            // 
            // Purge2
            // 
            this.Purge2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Purge2.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.Purge2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkOrchid;
            this.Purge2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Purge2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Purge2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Purge2.ForeColor = System.Drawing.Color.Lime;
            this.Purge2.Location = new System.Drawing.Point(932, 458);
            this.Purge2.Name = "Purge2";
            this.Purge2.Size = new System.Drawing.Size(76, 30);
            this.Purge2.TabIndex = 70;
            this.Purge2.Text = "Purge";
            this.Purge2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Purge2.UseVisualStyleBackColor = true;
            this.Purge2.Click += new System.EventHandler(this.Purge2_Click);
            // 
            // label_x2
            // 
            this.label_x2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_x2.AutoEllipsis = true;
            this.label_x2.BackColor = System.Drawing.Color.Transparent;
            this.label_x2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_x2.ForeColor = System.Drawing.Color.Lime;
            this.label_x2.Location = new System.Drawing.Point(805, 333);
            this.label_x2.Name = "label_x2";
            this.label_x2.Size = new System.Drawing.Size(97, 24);
            this.label_x2.TabIndex = 69;
            this.label_x2.Text = "Channel 1";
            // 
            // label_y2
            // 
            this.label_y2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_y2.AutoEllipsis = true;
            this.label_y2.BackColor = System.Drawing.Color.Transparent;
            this.label_y2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_y2.ForeColor = System.Drawing.Color.Lime;
            this.label_y2.Location = new System.Drawing.Point(804, 368);
            this.label_y2.Name = "label_y2";
            this.label_y2.Size = new System.Drawing.Size(98, 24);
            this.label_y2.TabIndex = 68;
            this.label_y2.Text = "Channel 2";
            // 
            // label_z2
            // 
            this.label_z2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_z2.AutoEllipsis = true;
            this.label_z2.BackColor = System.Drawing.Color.Transparent;
            this.label_z2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_z2.ForeColor = System.Drawing.Color.Lime;
            this.label_z2.Location = new System.Drawing.Point(805, 402);
            this.label_z2.Name = "label_z2";
            this.label_z2.Size = new System.Drawing.Size(97, 24);
            this.label_z2.TabIndex = 67;
            this.label_z2.Text = "Channel 3";
            // 
            // comboBox6
            // 
            this.comboBox6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(913, 405);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(101, 21);
            this.comboBox6.TabIndex = 64;
            // 
            // comboBox5
            // 
            this.comboBox5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(913, 373);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(101, 21);
            this.comboBox5.TabIndex = 63;
            // 
            // comboBox4
            // 
            this.comboBox4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(913, 337);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(101, 21);
            this.comboBox4.TabIndex = 62;
            // 
            // Load_file2
            // 
            this.Load_file2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Load_file2.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.Load_file2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkOrchid;
            this.Load_file2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Load_file2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Load_file2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Load_file2.ForeColor = System.Drawing.Color.Lime;
            this.Load_file2.Location = new System.Drawing.Point(809, 458);
            this.Load_file2.Name = "Load_file2";
            this.Load_file2.Size = new System.Drawing.Size(76, 30);
            this.Load_file2.TabIndex = 61;
            this.Load_file2.Text = "Initiate";
            this.Load_file2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Load_file2.UseVisualStyleBackColor = true;
            this.Load_file2.Click += new System.EventHandler(this.Load_file2_Click);
            // 
            // file2
            // 
            this.file2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.file2.AutoEllipsis = true;
            this.file2.BackColor = System.Drawing.Color.Transparent;
            this.file2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.file2.ForeColor = System.Drawing.Color.Lime;
            this.file2.Location = new System.Drawing.Point(868, 294);
            this.file2.Name = "file2";
            this.file2.Size = new System.Drawing.Size(100, 25);
            this.file2.TabIndex = 66;
            this.file2.Text = "File2";
            this.file2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // file1
            // 
            this.file1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.file1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.file1.AutoEllipsis = true;
            this.file1.BackColor = System.Drawing.Color.Transparent;
            this.file1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.file1.ForeColor = System.Drawing.Color.Lime;
            this.file1.Location = new System.Drawing.Point(867, 40);
            this.file1.Name = "file1";
            this.file1.Size = new System.Drawing.Size(100, 25);
            this.file1.TabIndex = 56;
            this.file1.Text = "File1";
            this.file1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // chart2
            // 
            this.chart2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chart2.BackColor = System.Drawing.Color.Black;
            this.chart2.BackImageTransparentColor = System.Drawing.Color.Black;
            this.chart2.BorderSkin.BackColor = System.Drawing.Color.Black;
            this.chart2.BorderSkin.PageColor = System.Drawing.Color.Black;
            chartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea1.AxisX.LineColor = System.Drawing.Color.White;
            chartArea1.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea1.AxisY.LineColor = System.Drawing.Color.White;
            chartArea1.BackColor = System.Drawing.Color.Black;
            chartArea1.BackSecondaryColor = System.Drawing.Color.Lime;
            chartArea1.IsSameFontSizeForAllAxes = true;
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.BackColor = System.Drawing.Color.Black;
            legend1.BorderColor = System.Drawing.Color.Yellow;
            legend1.BorderWidth = 0;
            legend1.ForeColor = System.Drawing.Color.Lime;
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(12, 188);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Chocolate;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Channel 2";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(428, 160);
            this.chart2.TabIndex = 72;
            this.chart2.Text = "chart2";
            // 
            // chart1
            // 
            this.chart1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chart1.BackColor = System.Drawing.Color.Black;
            this.chart1.BackImageTransparentColor = System.Drawing.Color.Black;
            chartArea2.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea2.AxisX.LineColor = System.Drawing.Color.White;
            chartArea2.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea2.AxisY.LineColor = System.Drawing.Color.White;
            chartArea2.BackColor = System.Drawing.Color.Black;
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.BackColor = System.Drawing.Color.Black;
            legend2.BorderColor = System.Drawing.Color.Yellow;
            legend2.BorderWidth = 0;
            legend2.ForeColor = System.Drawing.Color.Lime;
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(12, 12);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Channel 1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(428, 160);
            this.chart1.TabIndex = 73;
            this.chart1.Text = "chart1";
            // 
            // chart3
            // 
            this.chart3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chart3.BackColor = System.Drawing.Color.Black;
            this.chart3.BackImageTransparentColor = System.Drawing.Color.Black;
            chartArea3.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea3.AxisX.LineColor = System.Drawing.Color.White;
            chartArea3.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea3.AxisY.LineColor = System.Drawing.Color.White;
            chartArea3.BackColor = System.Drawing.Color.Black;
            chartArea3.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea3);
            legend3.BackColor = System.Drawing.Color.Black;
            legend3.BorderColor = System.Drawing.Color.Yellow;
            legend3.BorderWidth = 0;
            legend3.ForeColor = System.Drawing.Color.Lime;
            legend3.Name = "Legend1";
            this.chart3.Legends.Add(legend3);
            this.chart3.Location = new System.Drawing.Point(12, 366);
            this.chart3.Name = "chart3";
            this.chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Channel 3";
            this.chart3.Series.Add(series3);
            this.chart3.Size = new System.Drawing.Size(428, 160);
            this.chart3.TabIndex = 74;
            this.chart3.Text = "chart3";
            // 
            // chart4
            // 
            this.chart4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.chart4.BackColor = System.Drawing.Color.Black;
            this.chart4.BackImageTransparentColor = System.Drawing.Color.Black;
            chartArea4.AxisX.IsMarginVisible = false;
            chartArea4.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea4.AxisX.LineColor = System.Drawing.Color.White;
            chartArea4.AxisY.IsMarginVisible = false;
            chartArea4.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea4.AxisY.LineColor = System.Drawing.Color.White;
            chartArea4.BackColor = System.Drawing.Color.Black;
            chartArea4.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea4.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea4.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Scaled;
            chartArea4.BackSecondaryColor = System.Drawing.Color.Black;
            chartArea4.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea4);
            legend4.BackColor = System.Drawing.Color.Black;
            legend4.BorderWidth = 0;
            legend4.ForeColor = System.Drawing.Color.Lime;
            legend4.Name = "Legend1";
            this.chart4.Legends.Add(legend4);
            this.chart4.Location = new System.Drawing.Point(482, 294);
            this.chart4.Margin = new System.Windows.Forms.Padding(2);
            this.chart4.Name = "chart4";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series4.Legend = "Legend1";
            series4.Name = "plot1";
            series4.YValuesPerPoint = 2;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series5.Legend = "Legend1";
            series5.Name = "plot2";
            this.chart4.Series.Add(series4);
            this.chart4.Series.Add(series5);
            this.chart4.Size = new System.Drawing.Size(268, 219);
            this.chart4.TabIndex = 75;
            this.chart4.Text = "chart4";
            // 
            // elementHost2
            // 
            this.elementHost2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.elementHost2.Location = new System.Drawing.Point(612, 43);
            this.elementHost2.Name = "elementHost2";
            this.elementHost2.Size = new System.Drawing.Size(151, 168);
            this.elementHost2.TabIndex = 80;
            this.elementHost2.Text = "elementHost2";
            this.elementHost2.Child = this.gauge11;
            // 
            // elementHost1
            // 
            this.elementHost1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.elementHost1.Location = new System.Drawing.Point(446, 43);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(160, 165);
            this.elementHost1.TabIndex = 79;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.Child = this.gauge1;
            // 
            // DAQHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1048, 542);
            this.Controls.Add(this.elementHost2);
            this.Controls.Add(this.elementHost1);
            this.Controls.Add(this.chart4);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.Purge2);
            this.Controls.Add(this.label_x2);
            this.Controls.Add(this.label_y2);
            this.Controls.Add(this.label_z2);
            this.Controls.Add(this.file2);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.Load_file2);
            this.Controls.Add(this.Purge1);
            this.Controls.Add(this.label_x1);
            this.Controls.Add(this.label_y1);
            this.Controls.Add(this.label_z1);
            this.Controls.Add(this.file1);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Load_file1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DAQHome";
            this.Text = "DAQHome";
            this.Load += new System.EventHandler(this.DAQHome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Purge1;
        private System.Windows.Forms.Label label_x1;
        private System.Windows.Forms.Label label_y1;
        private System.Windows.Forms.Label label_z1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button Load_file1;
        private System.Windows.Forms.Button Purge2;
        private System.Windows.Forms.Label label_x2;
        private System.Windows.Forms.Label label_y2;
        private System.Windows.Forms.Label label_z2;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Button Load_file2;
        private System.Windows.Forms.Label file2;
        private System.Windows.Forms.Label file1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private Gauge gauge1;
        private System.Windows.Forms.Integration.ElementHost elementHost2;
        private Gauge1 gauge11;
    }
}