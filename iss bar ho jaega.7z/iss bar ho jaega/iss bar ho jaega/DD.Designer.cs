﻿namespace iss_bar_ho_jaega
{
    partial class DD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label1 = new System.Windows.Forms.Label();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.elementHost6 = new System.Windows.Forms.Integration.ElementHost();
            this.bps11 = new iss_bar_ho_jaega.bps1();
            this.elementHost5 = new System.Windows.Forms.Integration.ElementHost();
            this.bps1 = new iss_bar_ho_jaega.bps();
            this.elementHost4 = new System.Windows.Forms.Integration.ElementHost();
            this.tps12 = new iss_bar_ho_jaega.tps1();
            this.elementHost3 = new System.Windows.Forms.Integration.ElementHost();
            this.tps2 = new iss_bar_ho_jaega.tps();
            this.elementHost2 = new System.Windows.Forms.Integration.ElementHost();
            this.gauge12 = new iss_bar_ho_jaega.Gauge1();
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.gauge2 = new iss_bar_ho_jaega.Gauge();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            this.chart1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chart1.BackColor = System.Drawing.Color.Black;
            this.chart1.BackImageTransparentColor = System.Drawing.Color.Black;
            chartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea1.AxisX.LineColor = System.Drawing.Color.White;
            chartArea1.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea1.AxisY.LineColor = System.Drawing.Color.White;
            chartArea1.BackColor = System.Drawing.Color.Black;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.BackColor = System.Drawing.Color.Black;
            legend1.BorderColor = System.Drawing.Color.Yellow;
            legend1.BorderWidth = 0;
            legend1.ForeColor = System.Drawing.Color.Lime;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(12, 12);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Channel 1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(428, 160);
            this.chart1.TabIndex = 74;
            this.chart1.Text = "chart1";
            // 
            // chart2
            // 
            this.chart2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chart2.BackColor = System.Drawing.Color.Black;
            this.chart2.BackImageTransparentColor = System.Drawing.Color.Black;
            this.chart2.BorderSkin.BackColor = System.Drawing.Color.Black;
            this.chart2.BorderSkin.PageColor = System.Drawing.Color.Black;
            chartArea2.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea2.AxisX.LineColor = System.Drawing.Color.White;
            chartArea2.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea2.AxisY.LineColor = System.Drawing.Color.White;
            chartArea2.BackColor = System.Drawing.Color.Black;
            chartArea2.BackSecondaryColor = System.Drawing.Color.Lime;
            chartArea2.IsSameFontSizeForAllAxes = true;
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            legend2.BackColor = System.Drawing.Color.Black;
            legend2.BorderColor = System.Drawing.Color.Yellow;
            legend2.BorderWidth = 0;
            legend2.ForeColor = System.Drawing.Color.Lime;
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            this.chart2.Location = new System.Drawing.Point(12, 183);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Chocolate;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Channel 2";
            this.chart2.Series.Add(series2);
            this.chart2.Size = new System.Drawing.Size(428, 160);
            this.chart2.TabIndex = 75;
            this.chart2.Text = "chart2";
            // 
            // chart4
            // 
            this.chart4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.chart4.BackColor = System.Drawing.Color.Black;
            this.chart4.BackImageTransparentColor = System.Drawing.Color.Black;
            chartArea3.AxisX.IsMarginVisible = false;
            chartArea3.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea3.AxisX.LineColor = System.Drawing.Color.White;
            chartArea3.AxisY.IsMarginVisible = false;
            chartArea3.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea3.AxisY.LineColor = System.Drawing.Color.White;
            chartArea3.BackColor = System.Drawing.Color.Black;
            chartArea3.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea3.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea3.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Scaled;
            chartArea3.BackSecondaryColor = System.Drawing.Color.Black;
            chartArea3.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea3);
            legend3.BackColor = System.Drawing.Color.Black;
            legend3.BorderWidth = 0;
            legend3.ForeColor = System.Drawing.Color.Lime;
            legend3.Name = "Legend1";
            this.chart4.Legends.Add(legend3);
            this.chart4.Location = new System.Drawing.Point(834, 158);
            this.chart4.Margin = new System.Windows.Forms.Padding(2);
            this.chart4.Name = "chart4";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series3.Legend = "Legend1";
            series3.Name = "plot1";
            series3.YValuesPerPoint = 2;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series4.Legend = "Legend1";
            series4.Name = "plot2";
            this.chart4.Series.Add(series3);
            this.chart4.Series.Add(series4);
            this.chart4.Size = new System.Drawing.Size(182, 190);
            this.chart4.TabIndex = 81;
            this.chart4.Text = "chart4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(981, 484);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 84;
            this.label1.Text = "label1";
            // 
            // chart3
            // 
            this.chart3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chart3.BackColor = System.Drawing.Color.Black;
            this.chart3.BackImageTransparentColor = System.Drawing.Color.Black;
            chartArea4.AxisX.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea4.AxisX.LineColor = System.Drawing.Color.White;
            chartArea4.AxisY.LabelStyle.ForeColor = System.Drawing.Color.Lime;
            chartArea4.AxisY.LineColor = System.Drawing.Color.White;
            chartArea4.BackColor = System.Drawing.Color.Black;
            chartArea4.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea4);
            legend4.BackColor = System.Drawing.Color.Black;
            legend4.BorderColor = System.Drawing.Color.Yellow;
            legend4.BorderWidth = 0;
            legend4.ForeColor = System.Drawing.Color.Lime;
            legend4.Name = "Legend1";
            this.chart3.Legends.Add(legend4);
            this.chart3.Location = new System.Drawing.Point(12, 370);
            this.chart3.Name = "chart3";
            this.chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.Legend = "Legend1";
            series5.Name = "Channel 3";
            this.chart3.Series.Add(series5);
            this.chart3.Size = new System.Drawing.Size(428, 160);
            this.chart3.TabIndex = 85;
            this.chart3.Text = "chart3";
            // 
            // elementHost6
            // 
            this.elementHost6.Location = new System.Drawing.Point(635, 365);
            this.elementHost6.Name = "elementHost6";
            this.elementHost6.Size = new System.Drawing.Size(160, 165);
            this.elementHost6.TabIndex = 89;
            this.elementHost6.Text = "elementHost6";
            this.elementHost6.Child = this.bps11;
            // 
            // elementHost5
            // 
            this.elementHost5.Location = new System.Drawing.Point(466, 365);
            this.elementHost5.Name = "elementHost5";
            this.elementHost5.Size = new System.Drawing.Size(160, 165);
            this.elementHost5.TabIndex = 88;
            this.elementHost5.Text = "elementHost5";
            this.elementHost5.Child = this.bps1;
            // 
            // elementHost4
            // 
            this.elementHost4.Location = new System.Drawing.Point(644, 183);
            this.elementHost4.Name = "elementHost4";
            this.elementHost4.Size = new System.Drawing.Size(151, 165);
            this.elementHost4.TabIndex = 87;
            this.elementHost4.Text = "elementHost4";
            this.elementHost4.Child = this.tps12;
            // 
            // elementHost3
            // 
            this.elementHost3.Location = new System.Drawing.Point(466, 184);
            this.elementHost3.Name = "elementHost3";
            this.elementHost3.Size = new System.Drawing.Size(160, 159);
            this.elementHost3.TabIndex = 86;
            this.elementHost3.Text = "elementHost3";
            this.elementHost3.Child = this.tps2;
            // 
            // elementHost2
            // 
            this.elementHost2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.elementHost2.Location = new System.Drawing.Point(644, 7);
            this.elementHost2.Name = "elementHost2";
            this.elementHost2.Size = new System.Drawing.Size(151, 168);
            this.elementHost2.TabIndex = 83;
            this.elementHost2.Text = "elementHost2";
            this.elementHost2.Child = this.gauge12;
            // 
            // elementHost1
            // 
            this.elementHost1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.elementHost1.Location = new System.Drawing.Point(466, 7);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(160, 165);
            this.elementHost1.TabIndex = 82;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.Child = this.gauge2;
            // 
            // DD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1048, 542);
            this.Controls.Add(this.elementHost6);
            this.Controls.Add(this.elementHost5);
            this.Controls.Add(this.elementHost4);
            this.Controls.Add(this.elementHost3);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.elementHost2);
            this.Controls.Add(this.elementHost1);
            this.Controls.Add(this.chart4);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.chart1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DD";
            this.Text = "DD";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Integration.ElementHost elementHost2;
        private Gauge1 gauge11;
        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private Gauge gauge1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private Gauge1 gauge12;
        private Gauge gauge2;
        private System.Windows.Forms.Integration.ElementHost elementHost3;
        private System.Windows.Forms.Integration.ElementHost elementHost4;
        private System.Windows.Forms.Integration.ElementHost elementHost5;
        private System.Windows.Forms.Integration.ElementHost elementHost6;
        private bps1 bps11;
        private bps bps1;
        private tps1 tps12;
        private tps tps2;
    }
}